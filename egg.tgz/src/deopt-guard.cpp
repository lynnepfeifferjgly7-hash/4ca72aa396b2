// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Insert deopt guards"); }
int main(){
  announce();
  return lionss_run_workload("deopt-guard");
}
