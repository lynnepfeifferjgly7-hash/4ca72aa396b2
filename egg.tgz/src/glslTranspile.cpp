// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Transpile GLSL to MSL"); }
int main(){
  announce();
  return lionss_run_workload("glslTranspile");
}
