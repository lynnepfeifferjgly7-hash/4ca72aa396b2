// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Simulate flaxen strands"); }
int main(){
  announce();
  return lionss_run_workload("flaxen");
}
