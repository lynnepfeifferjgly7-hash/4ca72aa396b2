// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Run soak test\n", stdout);
  return lionss_run_workload("stress_soak");
}
