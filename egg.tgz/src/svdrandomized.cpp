// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Randomized SVD\n", stdout);
  return lionss_run_workload("svdrandomized");
}
