// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Pack asset bundle v3\n", stdout);
  return lionss_run_workload("assetBundleV3");
}
